const { MessageEmbed } = require('discord.js');
const { prefix } = require(`${process.cwd()}/config`);
const moment = require('moment');
const Pro = require('pro.db');

// Function to get total punishments
function getTotalPunishments(member) {
  const totalMutes = Pro.get(`Total_Mutes_${member.id}`) || 0;
  const totalVoiceMutes = Pro.get(`Total_voice_${member.id}`) || 0;
  const totalPrisons = Pro.get(`Total_Prisons_${member.id}`) || 0;
  const currentMute = Pro.get(`Muted_Member_${member.id}`);
  const currentVoiceMute = Pro.get(`voicemute_${member.id}`);
  const currentPrison = Pro.get(`Prison_Member_${member.id}`);

  let currentMuteInfo = 'لا يوجد عقوبة حالية';
  if (currentMute) {
    const remainingMuteTime = moment.utc(currentMute.times).diff(moment.utc(), 'minutes');
    currentMuteInfo = `\`الاسكات الحالي:\`  ${currentMute.reason} 
     \`ينتهي بعد : \`${remainingMuteTime} دقيقة
     \`من قبل :\` <@${currentMute.by}>`;
  }

  let currentVoiceMuteInfo = 'لا يوجد عقوبة حالية';
  if (currentVoiceMute) {
    const remainingVoiceMuteTime = moment.utc(currentVoiceMute.times).diff(moment.utc(), 'minutes');
    currentVoiceMuteInfo = `\`الميوت الحالي:\`  ${currentVoiceMute.reason} 
     \` ينتهي بعد :\` ${remainingVoiceMuteTime} دقيقة
       \`من قبل :\` <@${currentVoiceMute.by}>`;
  }

  let currentPrisonInfo = 'لا يوجد عقوبة حالية';
  if (currentPrison) {
    const remainingPrisonTime = moment.utc(currentPrison.times).diff(moment.utc(), 'minutes');
    currentPrisonInfo = `\`السجن الحالي:\` ${currentPrison.reason}
     \` ينتهي بعد :\` ${remainingPrisonTime} دقيقة
      \` من قبل :\` <@${currentPrison.by}>`;
  }

  return { totalMutes, totalVoiceMutes, totalPrisons, currentMuteInfo, currentVoiceMuteInfo, currentPrisonInfo };
}

module.exports = {
  name: 'infractions',
  aliases: ['عقوباتي'],
  run: async (client, message, args) => {
    const isEnabled = Pro.get(`command_enabled_${module.exports.name}`);
    if (isEnabled === false) {
        return; 
    }
    
    const Color = Pro.get(`Guild_Color_${message.guild.id}`) || '#5c5e64';
    if (!Color) return;

    const allowedRoleId = Pro.get(`Allow_Command_infractions_${message.guild.id}`);
    const allowedRole = message.guild.roles.cache.get(allowedRoleId);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);

    if (!isAuthorAllowed && !message.member.permissions.has('ADMINISTRATOR')) {
      return message.react('❌');
    }

    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!member) {
      const embed = new MessageEmbed()
        .setColor(Color)
        .setDescription(`**يرجى استعمال الأمر بالطريقة الصحيحة.\n${prefix}infractions <@${message.author.id}>**`);
      return message.reply({ embeds: [embed] });
    }

    const { totalMutes, totalVoiceMutes, totalPrisons, currentMuteInfo, currentVoiceMuteInfo, currentPrisonInfo } = getTotalPunishments(member);
    const logEmbed = new MessageEmbed()
      .setColor(Color)
      .setAuthor(member.user.tag, member.user.displayAvatarURL({ dynamic: true }))
      .setDescription(`**العقوبات\n\nالعقوبات السابقة:\nالسجن: ${totalPrisons}\nالاسكات: ${totalMutes}\nالميوت: ${totalVoiceMutes}\n\nالسجن الحالي:\n${currentPrisonInfo}\n\nالاسكات الحالي:\n${currentMuteInfo}\n\nالميوت الحالي:\n${currentVoiceMuteInfo}**`);

    message.channel.send({ embeds: [logEmbed] });
  }
};
