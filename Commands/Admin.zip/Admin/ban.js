const { MessageEmbed } = require("discord.js");
const { prefix, owners } = require(`${process.cwd()}/config`);
const Pro = require(`pro.db`);

// Define a map to keep track of bans issued by each user
const banCount = new Map();

// Reset ban count for each user after 24 hours
setInterval(() => {
  banCount.clear(); // Clear all ban counts
}, 24 * 60 * 60 * 1000); // Reset ban count every 24 hours

module.exports = {
  name: 'ban',
  aliases: ['برا', 'شقطحح', 'شقطح', 'ملحد', 'تفه'],
  run: async (client, message) => {
    const Color = Pro.get(`Guild_Color = ${message.guild.id}`) || message.guild.me.displayHexColor || `#000000`;
    if (!Color) return;

    const db = Pro.get(`Allow - Command ban = [ ${message.guild.id} ]`);
    const allowedRole = message.guild.roles.cache.get(db);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);

    // Check if the user has reached the ban limit
    if (banCount.has(message.author.id) && banCount.get(message.author.id) >= 3) {
      return message.reply(':rolling_eyes: - **The ban today\'s limit has been exceeded.**');
    }

    if (!isAuthorAllowed && message.member.id !== db && !message.member.permissions.has('BAN_MEMBERS')) {
      return message.react(`❌`);
    }

    const args = message.content.trim().split(/ +/);
    let member;

    // Attempt to fetch member from mention; otherwise check if ID is valid
    if (message.mentions.members.size) {
      member = message.mentions.members.first();
    } else if (args[1] && !isNaN(args[1])) {
      // Check if input is a number
      member = await message.guild.members.fetch(args[1]).catch(() => null);
    } else {
      // Display Usage Info if no valid member was found
      const dbAliases = Pro.get(`aliases_${module.exports.name}`) || []; // Retrieve aliases from the database
      const allAliases = [...new Set([...module.exports.aliases, ...dbAliases])]; // Combine and deduplicate aliases
      const aliases = allAliases.join(', '); // Format aliases for display

      const embed = new MessageEmbed()
        .setColor(Color || `#000000`)
        .setTitle("Command: ban")
        .setDescription("Bans a member.")
        .addField("Aliases:", aliases || 'لا يوجد.')
        .addField("Usage:", `\`${prefix}ban [user]\``)
        .addField("Examples:", `\`${prefix}ban @user\`\n\`${prefix}ban 123456789012345678\``) // Sample ID usage
        .setFooter("Please mention the user to ban or provide their ID.");

      return message.reply({ embeds: [embed] });
    }

    // Check if the member is the bot itself
    if (member.id === client.user.id) {
      return message.reply("**🙄 ما تبندني وانا ولد هوك.**");
    }

    // Check if the bot has permission to ban members
    if (!message.guild.me.permissions.has('BAN_MEMBERS')) {
      return message.reply('**🙄 I do not have permission to ban members.**');
    }

    // Check if the member is trying to ban someone with the BAN_MEMBERS permission
    if (member.permissions.has('BAN_MEMBERS')) {
      return message.reply('**🙄 You cannot ban this member.**');
    }

    // Check if the member is trying to ban themselves
    if (member.id === message.author.id) {
      return message.reply("**🙄 You cannot ban yourself.**");
    }

    const reason = args.slice(2).join(' ') || 'No reason provided'; // Extract the reason from the command arguments

    // Check if the member is already banned
    const bans = await message.guild.bans.fetch();
    if (bans.has(member.id)) {
      return message.reply("**This user is already banned.**");
    }

    try {
      await message.guild.members.ban(member, { reason }); // Pass the reason as an option to the ban method
      message.reply(`**:white_check_mark: ${member} banned from the server! :airplane:.**`);

      // Increment the ban count for the user
      const currentCount = banCount.get(message.author.id) || 0;
      banCount.set(message.author.id, currentCount + 1);

      // Logging the ban action
      const logbanunban = Pro.get(`logbanunban_${message.guild.id}`);
      const logChannel = message.guild.channels.cache.find((c) => c.id === logbanunban);

      if (logChannel) {
        const bannedMemberAvatar = member.user.displayAvatarURL({ dynamic: true });
        const embedLog = new MessageEmbed()
          .setColor("#880013")
          .setAuthor(member.user.tag, bannedMemberAvatar)
          .setDescription(`**حظر عضو**\n\n**لـ : <@${member.id}>**\n**بواسطة : <@${message.author.id}>**\n\`\`\`Reason : ${reason}\`\`\``)
          .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) })
          .setThumbnail('https://cdn.discordapp.com/attachments/1093303174774927511/1138892172574326874/82073587-11BA-4E4B-AC8F-8857CD89282F.png');

        await logChannel.send({ embeds: [embedLog] });
      }

      message.react(`✅`);
    } catch (error) {
      console.error(error);
      message.reply("**An error occurred while trying to ban the member.**");
    }
  }
};