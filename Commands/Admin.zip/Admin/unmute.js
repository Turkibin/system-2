const { MessageEmbed } = require("discord.js");
const { prefix } = require(`${process.cwd()}/config`);
const Pro = require('pro.db');
const moment = require('moment');

module.exports = {
  name: 'unmute',
  aliases: ['تكلم'],
  description: "A command to unmute a member.",
  run: async (client, message, args) => {
    const Color = Pro.get(`Guild_Color_${message.guild.id}`) || message.guild.me.displayHexColor || `#000000`;

    // Check if the command is allowed
    const db = Pro.get(`Allow_Command_unmute_${message.guild.id}`);
    const allowedRole = message.guild.roles.cache.get(db);
    const isAuthorAllowed = allowedRole ? message.member.roles.cache.has(allowedRole.id) : false;

    // Check if user is in the allow list
    const allowList = Pro.get(`allowed_unpunish_${message.guild.id}`) || [];
    const isAllowedMember = allowList.includes(message.author.id);

    // Allow unmute if the user has permission via role, is in allow list, or has permission to mute members
    if (!isAuthorAllowed && !isAllowedMember && !message.member.permissions.has('MUTE_MEMBERS')) {
      return message.reply('❌ - **You do not have permission to unmute members.**');
    }

    let member;
    if (message.mentions.members.size > 0) {
      member = message.mentions.members.first();
    } else if (args[0]) {
      const memberId = args[0];
      member = message.guild.members.cache.get(memberId) || await message.guild.members.fetch(memberId).catch(() => null);
    }

    if (!member) {
      const aliasString = module.exports.aliases.join(", ");
      const embed = new MessageEmbed()
        .setColor(Color)
        .setTitle("Command: unmute")
        .setDescription("Unmute a member.")
        .addFields(
          { name: "Aliases:", value: aliasString || "None" },
          { name: "Usage:", value: `${prefix}unmute <@user>` },
          { name: "Example:", value: `${prefix}unmute @user` }
        )
        .setFooter({ text: "Please mention the user to unmute." });
      return message.reply({ embeds: [embed] });
    }

    // Check for the Muted role
    let role = message.guild.roles.cache.find(role => role.name === 'Muted');
    if (!role) {
      return message.reply('**Could not find the Muted role.**');
    }

    // Only attempt to unmute if the member is muted
    if (!member.roles.cache.has(role.id)) {
      return message.reply('**This member is not muted.**');
    }

    try {
      const prisonData = await Pro.get(`Muted_Member_${member.id}`);
      const prisonReason = prisonData ? prisonData.reason : "سبب الاسكات غير معروف";

      // Check if the mute system is enabled
      const isMuteSystemEnabled = await Pro.get(`check_unmute_enabled_${message.guild.id}`);    
      
      if (isMuteSystemEnabled) {
        // If the mute system is enabled, check if the person trying to unmute is the one who muted the member
        const lastMuteAuthor = await Pro.get(`Muted_By_${member.id}`);
        if (lastMuteAuthor && lastMuteAuthor !== message.author.id && !isAllowedMember) {
          return message.reply('❌ - **You cannot unmute this member because you did not mute them.**');
        }
      }

      // Remove the Muted role
      await member.roles.remove(role);
      message.reply(`:white_check_mark: ${member.user.username} has been unmuted!`);

      // Log the action
      let logChannelId = Pro.get(`logtmuteuntmute_${message.guild.id}`);
      const logChannel = message.guild.channels.cache.find(channel => channel.id === logChannelId);

      if (logChannel) {
        const logEmbed = new MessageEmbed()
          .setAuthor(member.user.tag, member.user.displayAvatarURL({ dynamic: true }))
          .setColor('#f5f5ff')
          .setDescription(`**فك الآسكات الكتابي\n\nالعضو : ${member}\nبواسطة : ${message.author}\n[Message](${message.url})\nفّك فيـ : \`${moment().format('HH:mm')}\`**\n\`\`\`Mute : ${prisonReason}\`\`\``)
          .setThumbnail(`https://cdn.discordapp.com/attachments/1091536665912299530/1153875266066710598/image_1.png`)
          .setFooter(`${message.author.tag}`, message.author.displayAvatarURL({ dynamic: true }));
        
        await logChannel.send({ embeds: [logEmbed] });
      }

      // Remove prison data
      if (prisonData) {
        await Pro.delete(`Muted_Member_${member.id}`);
        await Pro.delete(`Muted_By_${member.id}`); // Remove the last mute author.
      } else {
        console.warn(`No mute data found for member ID ${member.id}.`);
      }
    } catch (error) {
      console.error(error);
      message.reply('**An error occurred while trying to unmute the member.** Please check the permissions and try again.');
    }
  },
};