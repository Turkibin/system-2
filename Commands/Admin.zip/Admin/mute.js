const { MessageEmbed } = require("discord.js");
const { prefix } = require(`${process.cwd()}/config`);
const Pro = require("pro.db");
const moment = require("moment");

module.exports = {
  name: "mute",
  aliases: ["اص", "اسكت"],
  description: "A command to mute a member.",
  category: "Informations",
  example: ["mute @member [reason] [duration]"],
  run: async (client, message) => {
    const db = Pro.get(`Allow - Command mute = [ ${message.guild.id} ]`);
    const allowedRole = message.guild.roles.cache.get(db);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id) || message.author.id === db || message.member.permissions.has("MANAGE_CHANNELS");

    if (!isAuthorAllowed) {
      return message.react("❌");
    }

    const args = message.content.split(" ").slice(1);
    const MemberID = message.mentions.members.first() || message.guild.members.cache.get(args[0]);

    if (!MemberID) {
      const aliasString = module.exports.aliases.join(", ");
      const embed = new MessageEmbed()
        .setColor("#FF0000")
        .setTitle("Command: mute")
        .setDescription("Mute a member.")
        .addField("Aliases:", aliasString || "None")
        .addField("Usage:", `${prefix}mute <@user> [reason] [duration]`)
        .addField("Example:", `${prefix}mute @user`)
        .setFooter("Please mention the user to mute.");
      return message.reply({ embeds: [embed] });
    }

    let muteRole = message.guild.roles.cache.find((role) => role.name === 'Muted');
    
    if (!muteRole) {
      muteRole = await message.guild.roles.create({
        name: 'Muted',
      });
    }

    // Set permissions for each text channel
    message.guild.channels.cache.filter(c => c.type === 'GUILD_TEXT').forEach(async (channel) => {
      await channel.permissionOverwrites.edit(muteRole, {
        SEND_MESSAGES: false,
        ADD_REACTIONS: false,
      }).catch(console.error);
    });

    // Set permissions for each voice channel
    message.guild.channels.cache.filter(c => c.type === 'GUILD_VOICE').forEach(async (channel) => {
      await channel.permissionOverwrites.edit(muteRole, {
        SPEAK: false,
      }).catch(console.error);
    });

    // Additional checks for MemberID
    if (MemberID.user.bot) {
      return message.reply("🙄**You cannot mute a bot!**");
    }

    if (MemberID.roles.highest.position >= message.member.roles.highest.position) {
      return message.reply(`🙄 - **You can't mute ${MemberID}.**`);
    }

    if (MemberID.id === message.member.id) {
      return message.reply("🙄**You cannot mute yourself!**");
    }

    if (MemberID.roles.cache.has(muteRole.id)) {
      return message.reply(`🙄 - **${MemberID} is already muted!**`);
    }

    const reason = args.slice(1, args.length - 1).join(' ') || 'No reason provided'; 
    const duration = parseInt(args[args.length - 1]); 
    const time = duration ? duration * 60 * 1000 : null; 

    await MemberID.roles.add(muteRole);
    await message.channel.send(`:white_check_mark: ${MemberID} **muted from the text!** :zipper_mouth:`);

    const logData = {
      time: time ? `${time / 1000 / 60} minutes` : 'Indefinitely',
      times: time ? endDate.format('LLLL') : 'Indefinitely',
      reason: reason,
      channel: message.channel.id,
      by: message.author.id,
      to: MemberID.id,
    };

    // Retrieve existing mute records or initialize an empty array
    const existingMutes = Pro.get(`Muted_Members_${MemberID.id}`) || [];
    existingMutes.push(logData); // Add the new mute record to the existing records

    // Store back updated records
    Pro.set(`Muted_Members_${MemberID.id}`, existingMutes);   
    await Pro.add(`Total_Mutes_${member.id}`, 1); // Increment total mutes count
    Pro.set(`Muted_By_${MemberID.id}`, message.author.id); // Save the author of the mute

    const logEmbed = new MessageEmbed()
      .setColor('#312e5d')
      .setAuthor(MemberID.user.tag, MemberID.user.displayAvatarURL({ dynamic: true }))
      .setDescription(`**Muted\n\nMember : <@${logData.to}>\nBy : <@${logData.by}>\nMessage : [here](${message.url})\nTime : \`${logData.time}\`**\n\`\`\`Reason : ${logData.reason}\`\`\``)
      .setThumbnail(`https://cdn.discordapp.com/attachments/1091536665912299530/1153875266066710598/image_1.png`)
      .setFooter({ text: `${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

    let logChannelId = Pro.get(`logtmuteuntmute_${message.guild.id}`);
    const logChannel = message.guild.channels.cache.find(channel => channel.id === logChannelId);

    if (logChannel) {
      logChannel.send({ embeds: [logEmbed] });
    }

    // Unmute the user after the specified duration if applicable
    if (time) {
      setTimeout(async () => {
        await MemberID.roles.remove(muteRole);
        await message.channel.send(`:loudspeaker: ${MemberID} has been unmuted after the duration!`);
        Pro.delete(`Muted_Member_${MemberID.id}`);
        Pro.delete(`Muted_By_${MemberID.id}`); // Remove the last mute author
      }, time);
    }
  },
};