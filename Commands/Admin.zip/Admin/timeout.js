const Discord = require("discord.js");
const { MessageEmbed } = require("discord.js");
const { prefix } = require(`${process.cwd()}/config`);
const Pro = require(`pro.db`);
const ms = require('ms');
const moment = require('moment');

module.exports = {
  name: "timeout",
  aliases: ["تايم"],
  description: "timeout a member",
  usage: ["!timeout @user"],
  run: async (client, message, args, config) => {

    const Color = Pro.get(`Guild_Color = ${message.guild.id}`) || '#f5f5ff';
    if (!Color) return;

    const db = Pro.get(`Allow - Command timeout = [ ${message.guild.id} ]`);
    const allowedRole = message.guild.roles.cache.get(db);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id) || message.author.id === db || message.member.permissions.has('MUTE_MEMBERS');

    if (!isAuthorAllowed) {
      return;
    }

    let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
    if (!args[0]) {
      const embed = new MessageEmbed()
        .setColor(`${Color || `#f5f5ff`}`)
        .setDescription(`**يرجى استعمال الأمر بالطريقة الصحيحة .\n${prefix}تايم <@${message.author.id}> 1h**`);
      return message.reply({ embeds: [embed] });
    }

    if (!member) {
      return message.reply({ content: `**لا يمكنني اعطاء ميوت لهاذا العضو .**` }).catch((err) => {
        console.log(`**لم أتمكن من الرد على الرسالة:**` + err.message);
      });
    }

    if (member.id === message.author.id) {
      return message.reply({ content: `**لا يمكنك اعطاء ميوت لنفسك .**` }).catch((err) => {
        console.log(`**لم أتمكن من الرد على الرسالة:**` + err.message);
      });
    }

    if (message.member.roles.highest.position < member.roles.highest.position) {
      return message.reply({ content: `:rolling_eyes: **You can't timeout ${member.user.username} since they have a higher role than you**` }).catch((err) => {
        console.log(`**لم أتمكن من الرد على الرسالة:**` + err.message);
      });
    }

    if (!args[1]) {
      return message.reply({ content: `**يرجي تحديد وقت التايم أوت.**` });
    }

    if (!args[1].endsWith('s') && !args[1].endsWith('m') && !args[1].endsWith('h') && !args[1].endsWith('d') && !args[1].endsWith('w')) {
      return message.reply({ content: `** يجب أن ينتهي الوقت بـ .** \`s / m / h / d / w\` ` });
    }
  
    message.reply(`**تم أعطاء تايم أوت للعضو <@${member.id}> بنجاح.**`);

    const timeoutDuration = ms(args[1]);
    const timeoutMessage = `**${message.member.nickname}** has timed you out for ${args[1]}.`;

    // Check if the timeout system is enabled
    const isTimeoutEnabled = await Pro.get(`check_untime_enabled_${message.guild.id}`);

    member.timeout(timeoutDuration, timeoutMessage)
      .then(() => {
        // Save timeout data in the database
        // After saving timeout data in the database
        // بعد كود إضافة العقوبة
        const timeoutData = {
          duration: timeoutDuration,
          reason: timeoutMessage,
          endsAt: Date.now() + timeoutDuration,
          by: message.author.id,
        };

        // Retrieve existing timeout records or initialize an empty array
        const existingTimeouts = Pro.get(`Timeout_Members_${member.id}`) || [];
        existingTimeouts.push(timeoutData); // Add the new timeout record to the existing records

        // Store back updated records
        Pro.set(`Timeout_Members_${member.id}`, existingTimeouts);             
        Pro.set(`timeout_${member.id}_${message.guild.id}`, timeoutData);

        const embed = new MessageEmbed()
          .setAuthor(member.user.tag, member.user.displayAvatarURL({ dynamic: true }))
          .setDescription(`**تايم أوت\n\nالعضو : <@${member.user.id}>\nبواسطة : <@${message.member.id}>\nفيـ : [Message](${message.url})\nالوقت : ${args[1]}\nاعطى فيـ : ${moment().format('HH:mm')}**\n\`\`\`Reason : No reason\`\`\`\ `)
          .setColor(`#312e5d`)
          .setFooter({ text: `${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
          .setThumbnail(`https://cdn.discordapp.com/attachments/1091536665912299530/1153875266066710598/image_1.png`);

        const chat = client.channels.cache.find(channel => channel.id === chatName);
        if (chat) {
          chat.send({ embeds: [embed] });
        } else {
          console.log(`Chat '${chatName}' not found.`);
        }

        // Inform the user that they have been timed out
        member.send(`تم أعطاء تايم أوت لك بنجاح لمدة ${args[1]} من قبل <@${message.member.id}>.`)
          .catch(err => console.log(`لم أتمكن من إرسال رسالة إلى ${member.user.tag}: ${err.message}`));

        // Send end timeout message after the specified duration
        setTimeout(() => {
          member.timeout(null); // Remove timeout
          Pro.delete(`timeout_${member.id}_${message.guild.id}`); // Delete data from the database
          const timeoutEndMessage = `**${member.user.username}**'s timeout has ended.`;
          if (chat) {
            chat.send(timeoutEndMessage);
          }
        }, timeoutDuration);

      })
      .catch((err) => {
        console.log(`Failed to timeout member: ${err.message}`);
      });
  },
};